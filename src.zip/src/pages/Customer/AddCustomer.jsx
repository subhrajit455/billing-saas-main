import ReusableForm from "@/components/Form/Form";
import { Button } from "@/components/ui/button";
import axios from "axios";
import { toast } from "sonner";
const customerFields = [
  { name: "firstName", label: "First Name", placeholder: "Enter first name" },
  { name: "lastName", label: "Last Name", placeholder: "Enter last name" },
  { name: "email", label: "Email", type: "email", placeholder: "Enter email" },
  { name: "phoneNumber", label: "Phone Number", placeholder: "Enter phone number" },
  { name: "address", label: "Address", placeholder: "Enter address" },
];

const initialCustomerData = {
  firstName: "",
  lastName: "",
  email: "",
  phoneNumber: "",
  address: ""
};

const Addcustomer=() =>{
  const userId = JSON.parse(localStorage.getItem("userId"));
  const handleSubmit = async (data) => {
    try {
      const response = await axios.post(`http://192.168.0.123:3000/api/v1/customer-add/${userId}`, data, {

        headers: {
          'Content-Type': 'application/json',
        },
      
      });
      console.log('API response:', response.data);
      toast.success("Customer created successfully!");
      // Optionally show success message or redirect
    } catch (error) {
      console.error('Error submitting data:', error.message);
      toast.error("Something went wrong.");
      // Optionally show error message
    }
  };

  return (
    <div
      className="bg-gradient-to-br p-3 min-h-screen flex items-center justify-center"

    >
      <div className="max-w-2xl bg-white/40  border w-full h-full p-8 rounded-3xl shadow-2xl  backdrop-blur-5xl  border-white/40 z-0"
      //   style={{
      //     background: "rgba(255,255,255,0.25)",
      //     boxShadow: "0 8px 32px 0 rgba(31, 38, 135, 0.37)",
      //     border: "1px solid rgba(255,255,255,0.18)",
      //     backdropFilter: "blur(16px)",
      //     WebkitBackdropFilter: "blur(16px)"
      //   }
      // }
      >
        <h2 className="text-3xl font-bold mb-8 text-[#a06ed7] drop-shadow text-center">Add Customer</h2>
        <ReusableForm
          fields={customerFields}
          onSubmit={handleSubmit}
          initialValues={initialCustomerData}
          submitButton={
            <Button
              type="submit"
              className="w-full mt-4 text-lg py-1 bg-[#a06ed7] text-white"
            
            >
              Save Customer
            </Button>
          }
        />
      </div>
    </div>
  );
}
export default Addcustomer;
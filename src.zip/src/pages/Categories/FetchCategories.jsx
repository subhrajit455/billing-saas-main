const FetchCategories =  () => {
    return(
        <>
        Fetch
        </>
    )
}
export default FetchCategories;
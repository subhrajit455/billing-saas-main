const FetchProducts = ()=>{
    return(
        <div>
            <h1>Fetch Products</h1>
        </div>
    )
}
export default FetchProducts;